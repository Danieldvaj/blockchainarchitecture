export class SpacePart {
    key: string;
    record: SpacePartRecord;
}

export class SpacePartRecord {
    currentState: string;
    spacePartId: string;
    holderId: string;
    originId: string;
    packingTimestamp: string;
    quantity: string;
}