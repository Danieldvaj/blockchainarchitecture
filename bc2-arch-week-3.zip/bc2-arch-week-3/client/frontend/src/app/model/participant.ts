export class Participant {
    id: string;
    name: string;
    role: string;
}