export class PartShipment {
    key: string;
    record: PartShipmentRecord
}

export class PartShipmentRecord {
    currentState: string;
    distributorId: string;
    spacePartsIds: string[];
    SpaceManufacturerID: string;
    shipmentCreation: string;
    shipmentId: string;
    shipperId: string;
}