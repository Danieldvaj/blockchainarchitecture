import { TestBed } from '@angular/core/testing';

import { SpacepartService } from './spacepart.service';

describe('SpacepartService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SpacepartService = TestBed.get(SpacepartService);
    expect(service).toBeTruthy();
  });
});
