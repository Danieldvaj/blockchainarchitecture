import { TestBed } from '@angular/core/testing';

import { PartShipmentService } from './part-shipment.service';

describe('PartShipmentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PartShipmentService = TestBed.get(PartShipmentService);
    expect(service).toBeTruthy();
  });
});
