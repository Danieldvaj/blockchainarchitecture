import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SpacePart } from '../model/spacepart';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class SpacepartService {

  constructor(private httpClient: HttpClient, private authService: AuthService) { }

  getSpaceParts() {

    const currentUser = this.authService.currentUser;

    if(!currentUser) {
      return null;
    }

    return this.httpClient.get<SpacePart[]>(`http://localhost:8080/rest/participants/${currentUser.id}/spaceparts`);
  }
}
