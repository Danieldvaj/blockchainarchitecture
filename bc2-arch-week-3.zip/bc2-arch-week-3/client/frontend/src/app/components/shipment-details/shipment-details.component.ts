import { Component, OnInit, Input } from '@angular/core';
import { PartShipment } from 'src/app/model/PartShipment';

@Component({
  selector: 'app-shipment-details',
  templateUrl: './shipment-details.component.html',
  styleUrls: ['./shipment-details.component.css']
})
export class ShipmentDetailsComponent implements OnInit {

  @Input('partShipment')
  element: PartShipment;

  constructor() { }

  ngOnInit() {
  }

}
