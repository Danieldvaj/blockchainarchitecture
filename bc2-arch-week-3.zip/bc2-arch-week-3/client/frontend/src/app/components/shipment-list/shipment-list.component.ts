import { Component, OnInit } from '@angular/core';
import { PartShipmentService } from 'src/app/services/part-shipment.service';
import { EventService } from 'src/app/services/event.service';
import { PartShipment } from 'src/app/model/PartShipment';

@Component({
  selector: 'app-shipment-list',
  templateUrl: './shipment-list.component.html',
  styleUrls: ['./shipment-list.component.css']
})
export class ShipmentListComponent implements OnInit {

  partShipments: PartShipment[];
  selectedShipment: PartShipment;

  constructor(private service: PartShipmentService, private eventService: EventService) { }

  ngOnInit() {
    this.load();
    this.eventService.subject.subscribe(
      msg => this.load(),
      err => console.log(err),
      () => console.log('complete')
    )
  }

  load() {
    this.service.getShipment().subscribe((data) => {
      this.partShipments = data;
    }, (error) => {
      console.error(error);
    });

  }

  selectShipment(shipment) {
    console.log('sel',this.selectShipment);
    this.selectedShipment = shipment;
  }

}
