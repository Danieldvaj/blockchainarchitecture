import { Component, OnInit } from '@angular/core';
import { SpacepartService } from 'src/app/services/spacepart.service';
import { SpacePart } from 'src/app/model/spacepart';
import { EventService } from 'src/app/services/event.service';

@Component({
  selector: 'app-spacepart-list',
  templateUrl: './spacepart-list.component.html',
  styleUrls: ['./spacepart-list.component.css']
})
export class SpacepartListComponent implements OnInit {

  spaceParts: SpacePart[];

  constructor(private service: SpacepartService, private eventService: EventService) { }

  ngOnInit() {
    this.load();
    this.eventService.subject.subscribe(
      msg => this.load(),
      err => console.log(err),
      () => console.log('complete')
    )
  }

  load() {
    this.service.getSpaceParts().subscribe((data) => {
      this.spaceParts = data;
    }, (error) => {
      console.error(error);
    });

  }

}
