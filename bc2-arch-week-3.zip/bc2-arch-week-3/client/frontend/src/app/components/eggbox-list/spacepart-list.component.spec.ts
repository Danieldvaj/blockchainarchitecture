import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpacepartListComponent } from './spacepart-list.component';

describe('SpacepartListComponent', () => {
  let component: SpacepartListComponent;
  let fixture: ComponentFixture<SpacepartListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpacepartListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpacepartListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
