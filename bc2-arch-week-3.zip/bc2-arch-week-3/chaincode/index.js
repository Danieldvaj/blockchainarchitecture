'use scrict';

const EggTrackingContract = require('./lib/egg-tracking-contract.js');

module.exports.contracts = [EggTrackingContract];